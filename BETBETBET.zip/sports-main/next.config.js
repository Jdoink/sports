/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true, // Keeps React in strict mode (good practice)
};

module.exports = nextConfig;
